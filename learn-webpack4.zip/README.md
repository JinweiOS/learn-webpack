# Learn-Webpack

## how to debug

In your loader project root dir, run `yalc publish`

then,

In this project, run `yalc add json-loader@1.0.0.0`;