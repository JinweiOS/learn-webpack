// import Vue from 'vue'
// import Single from './Single.vue'
import versionInfo from './config/index.pjw'
console.log(versionInfo)

// const app = new Vue({
//     render: h => h(Single)
// });

// app.$mount('#app')